package day03.homework1.pay;

/**
 * Singleton Pattern
 */
public class PaycoPay extends Payment {
    private static PaycoPay paycoPay;

    /**
     * @return 페이코 결제 방식
     */
    public static PaycoPay getInstance() {
        if (paycoPay == null) {
            paycoPay = new PaycoPay("페이코 페이");
        }

        return paycoPay;
    }

    /**
     * @param payName 결제 방식명
     */
    public PaycoPay(String payName) {
        super(payName);
    }

    /**
     * @param totalPrice 할인된 지불 총액(20% 할인)
     * @return 결제 성공 여부
     */
    @Override
    public boolean pay(int totalPrice) {
        return this.getMoney() - totalPrice * 0.8 >= 0;
    }

    /**
     * @param totalPrice 할인된 지불 총액
     */
    @Override
    public void printCoins(int totalPrice) {
        System.out.println("할인된 결제 금액: " + (int)(totalPrice * 0.8));
    }
}
