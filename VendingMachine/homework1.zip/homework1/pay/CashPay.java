package day03.homework1.pay;

import java.util.Arrays;

public class CashPay extends Payment implements Payable {
    private static CashPay cashPay;
    private final int[] changes = {100, 500, 1000, 5000, 10000, 50000};
    private final int[] coinsCount;

    /**
     * @return 현금 결제 방식
     */
    public static CashPay getInstance() {
        if (cashPay == null) {
            cashPay = new CashPay("현금");
        }

        return cashPay;
    }

    /**
     * @param payName 결제 방식명
     */
    public CashPay(String payName) {
        super(payName);

        coinsCount = new int[changes.length];
        Arrays.fill(coinsCount, 0);
    }


    /**
     * @param totalPrice 지불 총액
     * @return 결제 성공 여부
     */
    @Override
    public boolean pay(int totalPrice) {
        int change = this.getMoney() - totalPrice;

        return change >= 0;
    }

    /**
     * @param totalPrice 지불 총액
     */
    @Override
    public void printCoins(int totalPrice) {
        int change = this.getMoney() - totalPrice;

        System.out.println("결제 금액: " + totalPrice);
        System.out.println("잔돈 반환: " + change + "원");
        for (int i = changes.length-1; pay(totalPrice) && i >= 0; i--) {
            coinsCount[i] += (change / changes[i]);
            change %= changes[i];

            System.out.println(changes[i] + "원: " + coinsCount[i] + "개");
        }
    }
}
