package day03.homework1.pay;

/**
 * Template Method Pattern
 */
public abstract class Payment implements Payable {

    private final String payName;
    private int money;

    /**
     * @param payName 결제 방식명
     */
    protected Payment(String payName) {
        this.payName = payName;
    }

    /**
     * @param pay 결제 성공 여부
     */
    @Override
    public void activePay(boolean pay) {
        System.out.println(payName + " 결제 중...");

        if (pay) {
            System.out.println(this.payName + " 결제 성공:)");
        } else {
            System.out.println(this.payName + " 결제 실패:( 금액 부족!");
        }
        System.out.println();
    }

    /**
     * @param money 사용자 지불 금액 정보
     */
    public void setMoney(int money) {
        this.money = money;
    }

    /**
     * @return 사용자 지불 금액 정보
     */
    public int getMoney() {
        return money;
    }

    /**
     * @return 결제 방식명
     */
    public String getName() {
        return this.payName;
    }

}
