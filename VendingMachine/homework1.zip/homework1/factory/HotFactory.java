package day03.homework1.factory;

/**
 * Singleton Pattern
 */
public class HotFactory extends DrinkFactory {

    private String cupName;
    private static HotFactory hotFactory;

    /**
     * @return 핫 팩토리
     */
    public static DrinkFactory getInstance() {
        if (hotFactory == null) {
            hotFactory = new HotFactory();
        }

        return hotFactory;
    }

    @Override
    public final void create() throws InterruptedException {
        setCupName();
        hasCup();
        getDrink();
    }

    @Override
    public void setCupName() {
        this.cupName = "종이 컵";
    }

    @Override
    public void hasCup() {
        System.out.println(this.cupName + "을 받으세요");
    }

    @Override
    public void getDrink() throws InterruptedException {
        System.out.println("Hot 음료를 받는 중입니다..");
        Thread.sleep(1000);
    }
}
