package day03.homework1.factory;

/**
 * Singleton Pattern
 */
public class IceFactory extends DrinkFactory {

    private String cupName;
    private static IceFactory iceFactory;

    /**
     * @return 아이스 팩토리
     */
    public static DrinkFactory getInstance() {
        if (iceFactory == null) {
            iceFactory = new IceFactory();
        }

        return iceFactory;
    }

    @Override
    public final void create() throws InterruptedException {
        setCupName();
        hasCup();
        getIce();
        getDrink();
    }

    @Override
    public void setCupName() {
        this.cupName = "플라스틱 컵";
    }

    @Override
    public void hasCup() {
        System.out.println(this.cupName + "을 받으세요");
    }

    /**
     * 아이스를 받는 과정 추가
     */
    public void getIce() throws InterruptedException {
        System.out.println("얼음을 받는 중입니다..");
        Thread.sleep(1000);
    }

    @Override
    public void getDrink() throws InterruptedException {
        System.out.println("Ice 음료를 받는 중입니다..");
        Thread.sleep(1000);
    }
}
