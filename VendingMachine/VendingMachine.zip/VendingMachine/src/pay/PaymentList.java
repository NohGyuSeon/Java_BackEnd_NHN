package pay;

/**
 * 결제 방식 정보 enum
 */
public enum PaymentList {
    CARDPAY(1, CardPay.getInstance()),
    CASHPAY(2, CashPay.getInstance()),
    KAKAOPAY(3, KakaoPay.getInstance()),
    PAYCOPAY(4, PaycoPay.getInstance());

    private final int number;
    private final Payment payment;

    /**
     * @param number 걸제 방식 고유 번호
     * @param payment 결제 방식
     */
    PaymentList(int number, Payment payment) {
        this.number = number;
        this.payment = payment;
    }

    /**
     * @return 결제 방식
     */
    public Payment getInstance() {
        return this.payment;
    }

    @Override
    public String toString() {
        return this.number + ". [" + this.payment.getName() + "]";
    }
}
