package pay;

public class KakaoPay extends Payment {
    private static KakaoPay kakaoPay;

    /**
     * @return 카카오 페이 결제 방식
     */
    public static KakaoPay getInstance() {
        if (kakaoPay == null) {
            kakaoPay = new KakaoPay("카카오 페이");
        }

        return kakaoPay;
    }

    /**
     * @param payName 결제 방식명
     */
    public KakaoPay(String payName) {
        super(payName);
    }

    /**
     * @param totalPrice 지불 총액
     * @return 결제 성공 여부
     */
    @Override
    public boolean pay(int totalPrice) {
        return this.getMoney() - totalPrice >= 0;
    }

    /**
     * @param totalPrice 지불 총액
     */
    @Override
    public void printCoins(int totalPrice) {
        System.out.println("결제 금액: " + totalPrice);
    }
}
