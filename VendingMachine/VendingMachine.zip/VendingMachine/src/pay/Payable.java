package pay;

/**
 * 결제 가능한 타입 정의
 */
public interface Payable {
    boolean pay(int totalPrice);
    void activePay(boolean pay);
    void printCoins(int totalPrice);
}
