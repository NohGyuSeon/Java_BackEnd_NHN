package pay;

/**
 * Singleton Pattern
 */
public class CardPay extends Payment {
    private static CardPay cardPay;

    /**
     * @return 카드 결제 방식
     */
    public static CardPay getInstance() {
        if (cardPay == null) {
            cardPay = new CardPay("카드");
        }

        return cardPay;
    }

    /**
     * @param payName 결제 방식명
     */
    public CardPay(String payName) {
        super(payName);
    }

    /**
     * @param totalPrice 지불 총액
     * @return 결제 성공 여부
     */
    @Override
    public boolean pay(int totalPrice) {
        return this.getMoney() - totalPrice >= 0;
    }

    /**
     * @param totalPrice 지불 총액
     */
    @Override
    public void printCoins(int totalPrice) {
        System.out.println("결제 금액: " + totalPrice);
    }
}
