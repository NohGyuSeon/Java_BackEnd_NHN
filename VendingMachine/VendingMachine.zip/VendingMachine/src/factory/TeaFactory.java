package factory;

/**
 * Singleton Pattern
 */
public class TeaFactory extends DrinkFactory {

    private String cupName;
    private static TeaFactory teaFactory;

    @Override
    public final void create() throws InterruptedException {
        setCupName();
        hasCup();
        getBrew();
        getDrink();
    }

    /**
     * @return 티 팩토리
     */
    public static DrinkFactory getInstance() {
        if (teaFactory == null) {
            teaFactory = new TeaFactory();
        }

        return teaFactory;
    }

    @Override
    public void setCupName() {
        this.cupName = "티백 종이컵";
    }

    @Override
    public void hasCup() {
        System.out.println(this.cupName + "을 받으세요");
    }

    /**
     * 차 팩토리에서 우려내는 과정 추가
     */
    public void getBrew() throws InterruptedException {
        System.out.println("차를 우려내는 중입니다..");
        Thread.sleep(2000);
    }

    @Override
    public void getDrink() throws InterruptedException {
        System.out.println("Tea 음료를 받는 중입니다..");
        Thread.sleep(1000);
    }
}
