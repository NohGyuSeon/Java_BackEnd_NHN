package factory;

/**
 * Template Method Pattern
 * Factory Method Pattern
 * 개별 팩토리에서 음료 제조 과정에 대한 차별성 -> 해당 팩토리로 책임을 구현 가능
 */
public abstract class DrinkFactory {

    public abstract void create() throws InterruptedException;

    abstract void setCupName();

    abstract void getDrink() throws InterruptedException;

    abstract void hasCup();
}
