package drink;

import factory.DrinkFactory;
import factory.HotFactory;
import factory.IceFactory;
import factory.TeaFactory;

/**
 * 음료 정보 enum
 */
public enum Drink {

    ICEAMERICANO(1,5100, Type.ICE, IceFactory.getInstance()),
    HOTAMERICANO(2,4500, Type.HOT, HotFactory.getInstance()),
    ESSPRESSO(3,4000, Type.HOT, HotFactory.getInstance()),
    COLDBLUE(4,5500, Type.ICE, IceFactory.getInstance()),
    HAZELNUT(5,5600, Type.ICE, IceFactory.getInstance()),
    GREENTEA(6,5000, Type.TEA, TeaFactory.getInstance()),
    CORNTEA(7,5200, Type.TEA, TeaFactory.getInstance()),
    BLACKTEA(8,5500, Type.TEA, TeaFactory.getInstance());

    private final int number;
    private final int price;
    private final Type type;
    private final DrinkFactory drinkFactory;

    /**
     * @param number 음료 고유 번호
     * @param price 음료 가격
     * @param type 음료 타입
     * @param drinkFactory 음료 팩토리
     */
    Drink(int number, int price, Type type, DrinkFactory drinkFactory) {
        this.number = number;
        this.price = price;
        this.type = type;
        this.drinkFactory = drinkFactory;
    }

    /**
     * @return 해당 음료 가격
     */
    public int getPrice() {
        return this.price;
    }

    /**
     * @return 해당 음료 팩토리
     */
    public DrinkFactory getInstance() {
        return this.drinkFactory;
    }

    @Override
    public String toString() {
        return this.number + ". [" + this.name() + "] 가격: " + this.price;
    }

}
