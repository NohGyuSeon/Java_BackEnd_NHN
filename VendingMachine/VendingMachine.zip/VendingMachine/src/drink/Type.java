package drink;

/**
 * 음료 타입
 */
public enum Type {
    ICE,
    HOT,
    TEA
}
