import framework.ActiveVendingMachine;
import framework.VendingMachine;
import java.util.Scanner;

/**
 * @author 노규선
 * @Date 2023.03.20
 *
 * 제조 방식과 판매 방식(결제 방식)은 분리되어야 한다.
 * 제조 방식은 Factory Method Pattern이 적용된다.
 * 각각의 제조 방식, 결제 방식은 Template Method Pattern이 적용된다.
 * 각각의 제조 방식, 결제 방식은 SingleTon Pattern이 적용된다.
 * ActiveVendingMachine에서 자판기의 동작을 모델링한다.
 */
public class Main {

    public static final int USERS_NUMBER = 5;

    public static void main(String[] args) {
        VendingMachine vendingMachine = new ActiveVendingMachine();
        Scanner sc = new Scanner(System.in);

        // try-with-source문은 일회성으로 사용 시, java.util.NoSuchElementException 예외 발생
        try {
            for (int i = 0; i < USERS_NUMBER; i++) {
                System.out.println(i + 1 + "번째 사용자 이용중 :)");
                vendingMachine.doSales(sc);
            }
            System.out.println("모든 사용자 구매 완료");

        } catch (Exception e) {
            e.printStackTrace();
            System.out.println(e.getMessage() + " 오류 발생 :(");
        } finally {
            sc.close();
        }
    }
}
