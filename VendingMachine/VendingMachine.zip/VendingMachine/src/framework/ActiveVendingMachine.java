package framework;

import drink.Drink;
import pay.Payment;
import pay.PaymentList;
import java.util.LinkedList;
import java.util.Objects;
import java.util.Queue;
import java.util.Scanner;

/**
 * 활성 자판기 머신 클래스
 * 장바구니에 들어있는 모든 음료를 poll()할 때마다 create() 메소드를 호출해야 함
 * 즉, 팩토리 클래스 추가만으로, 해당 팩토리에 상응하는 음료를 생산해낼 수 있어야 함
 */
public class ActiveVendingMachine implements VendingMachine {
    private final Queue<Drink> drinkInventory;
    private Payment payment;
    private int totalPrice;
    private int inventorySize;

    public ActiveVendingMachine() {
        drinkInventory = new LinkedList<>();
        payment = null;
        totalPrice = 0;
        inventorySize = 0;
    }

    @Override
    public void getMenuList() {
        System.out.println("\n자판기 메뉴 출력!");

        for (Drink menu : Drink.values()) {
            System.out.println(menu.toString());
        }
    }

    /**
     * @param number 음료 고유 번호
     */
    @Override
    public void addDrink(int number) {
        drinkInventory.add(getDrink(number));
        totalPrice += getDrinkPrice(number);
    }

    /**
     * @param number 음료 고유 번호
     * @return 해당 음료
     */
    public Drink getDrink(int number) {
        return Drink.values()[number];
    }

    /**
     * @param number 음료 고유 번호
     * @return 해당 음료 가격
     */
    public int getDrinkPrice(int number) {
        return Drink.values()[number].getPrice();
    }

    @Override
    public void getInventoryList() {
        System.out.println("\n장바구니 목록 출력!");

        for (Drink drink : drinkInventory) {
            System.out.println(drink.toString());
        }
        System.out.println();
    }

    @Override
    public void setInventorySize(int inventorySize) {
        this.inventorySize = inventorySize;
    }

    @Override
    public void createDrink() {
        System.out.println("주문한 음료 수: " + inventorySize + "\n");
        try {
            for (int i = 0; i < inventorySize; i++) {

                Objects.requireNonNull(this.drinkInventory.peek()).getInstance().create();

                System.out.print("추출된 음료: ");
                System.out.println(this.drinkInventory.poll() + "\n"); // 잘 빠져나가는지 확인용 라인
            }
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void clearDrink() {
        drinkInventory.clear();
    }

    @Override
    public void clearDrinkPrice() {
        totalPrice = 0;
    }

    @Override
    public void selectPay(Scanner sc) {
        System.out.println("\n결제 방식 출력!");

        for (PaymentList paymentList : PaymentList.values()) {
            System.out.println(paymentList.toString());
        }

        System.out.print("\n결제 방식을 입력하세요: ");
        int type = sc.nextInt() - 1;

        payment = PaymentList.values()[type].getInstance();
    }

    /**
     * @param sc 스캐너
     */
    @Override
    public void selectDrink(Scanner sc) {
        int number;
        while (true) {
            System.out.print("\n무엇을 살 것입니까?(0 입력 시 종료) "); // 번호 Enum에 추가할 것
            number = sc.nextInt() - 1;

            if (number >= 0) {
                addDrink(number);
                System.out.println(getDrink(number).toString() + "이 장바구니에 담겼습니다.");
            } else {
                break;
            }
        }
    }

    /**
     * @param isSuccessPay 결제 성공 여부
     */
    @Override
    public void isCreateDrink(boolean isSuccessPay) {
        if (payment.pay(totalPrice)) {
            createDrink();
            // 사용자 한명의 이용 종료 시, 자판기 값 초기화
            // 결제 실패 시, 자판기 값 초기화
        }
        clearDrink();
        clearDrinkPrice();
    }

    /**
     * @param sc 스캐너
     */
    @Override
    public void doSales(Scanner sc) {
        System.out.print("자판기에 넣을 돈 입력: ");
        int money = sc.nextInt();

        selectPay(sc);  // 결제 방법 선택

        payment.setMoney(money);    // 사용자 지불 금액 정보 저장

        getMenuList();      // 음료 메뉴 리스트 출력

        selectDrink(sc);    // 사용자 음료 선택

        getInventoryList();     // 장바구니 리스트 출력

        setInventorySize(drinkInventory.size());    // 장바구니에 담긴 음료 수 저장

        payment.activePay(payment.pay(totalPrice));     // 금액에 따른 결제 성공 여부 확인

        payment.printCoins(totalPrice);     // 결제 금액 출력 (현금 결제 시, 잔돈까지 출력)

        isCreateDrink(payment.pay(totalPrice));     // 음료 제조 및 추출에 대한 판별
    }
}
