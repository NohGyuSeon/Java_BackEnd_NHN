package framework;

import drink.Drink;
import java.util.Scanner;

/**
 * 자판기 타입 정의
 */
public interface VendingMachine {

    void getMenuList();

    void addDrink(int number);

    Drink getDrink(int number);

    int getDrinkPrice(int number);

    void getInventoryList();

    void setInventorySize(int inventorySize);

    void createDrink();

    void clearDrink();

    void clearDrinkPrice();

    void selectPay(Scanner sc);

    void selectDrink(Scanner sc);

    void isCreateDrink(boolean isSuccessPay);

    void doSales(Scanner sc);
}
