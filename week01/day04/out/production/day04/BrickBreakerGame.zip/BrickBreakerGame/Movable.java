package BrickBreakerGame;

/**
 * 움직일 수 있는 객체들에 대한 타입 지정 Movable 인터페이스
 */
public interface Movable {
    void update();  // 변위 업데이트
}
